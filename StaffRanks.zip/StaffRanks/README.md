#Annoncement_ranks



This mods is a mod that adds ranks and a command to make announcements. 
This mod works with privileges. A privilege = a rank:

Privilege Name = Rank name

    server = Admin
    moderator = Moderator
    developer = Developer
    builder = Builder
    contributor = Contributor
    vip = VIP
    player = Player

To add or modify ranks look in the "Readme.md". 
Github: https://github.com/Salzar-R2D2/StaffRanks

-- Changes

- To change the color of a rank simply change the color "#...." in the rank code.
- To add a rank you just have to copy paste the code of the rank example, 
in the file "example.lua", and to modify at your will what is written between "<>".