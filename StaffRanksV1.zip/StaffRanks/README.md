#Annoncement_ranks

This mods is a mod that adds ranks and a command to make announcements.

Here are the different ranks:

    Admin
    Moderator
    Developer
    Builder
    Contributor
    VIP
    Player
